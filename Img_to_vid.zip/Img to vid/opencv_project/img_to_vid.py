import cv2
import os

path = 'opencv_project/imgs'
output_path = 'opencv_project/vid'
output_video_name = 'sunset_vid.mp4'
output_video_full_path = output_path + output_video_name

pre_imgs = os.listdir(path)
# print(pre_imgs)
img = []

for i in pre_imgs:
    i = path+i 
    # print(i) 
    img.append(i)

# print(img)

cv2_fourcc = cv2.VideoWriter_fourcc(*'mp4')

frame = cv2.imread(img[0])
size = list(frame.shape)
del size[2]
size.reverse()
# print(size)

video = cv2.Videowriter(output_video_full_path, cv2_fourcc, 24, size) #output: video name, fourcc, fps, size

for i in range(len(img)):
    video.write(cv2.imread(img[i]))
    # print('frame', i+1, 'of', len(img))
video.release()